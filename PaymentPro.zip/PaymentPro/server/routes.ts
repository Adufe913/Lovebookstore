import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, loginSchema, sendMoneySchema, insertWithdrawalSchema } from "@shared/schema";
import { createPaypalOrder, capturePaypalOrder, loadPaypalDefault } from "./paypal";
import { z } from "zod";

// Session user type
declare module "express-session" {
  interface SessionData {
    user?: { id: number; email: string; firstName: string; lastName: string };
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication middleware
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.session || !req.session.user) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    next();
  };

  // Register user
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }

      const user = await storage.createUser(userData);
      
      // Auto-login after registration
      req.session.user = {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
      };

      res.json({ user: req.session.user });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Login user
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = loginSchema.parse(req.body);
      
      const user = await storage.getUserByEmail(email);
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      req.session.user = {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
      };

      res.json({ user: req.session.user });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Logout user
  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Could not log out" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  // Get current user profile
  app.get("/api/auth/me", requireAuth, async (req, res) => {
    try {
      const user = await storage.getUser(req.session.user!.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get user transactions
  app.get("/api/transactions", requireAuth, async (req, res) => {
    try {
      const transactions = await storage.getTransactionsByUserId(req.session.user!.id);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Send money
  app.post("/api/transactions/send", requireAuth, async (req, res) => {
    try {
      const { toEmail, amount, description } = sendMoneySchema.parse(req.body);
      const fromUserId = req.session.user!.id;
      
      // Get sender user
      const fromUser = await storage.getUser(fromUserId);
      if (!fromUser) {
        return res.status(404).json({ message: "Sender not found" });
      }

      // Get recipient user
      const toUser = await storage.getUserByEmail(toEmail);
      if (!toUser) {
        return res.status(404).json({ message: "Recipient not found" });
      }

      const amountNum = parseFloat(amount);
      const currentBalance = parseFloat(fromUser.balance);

      // Check if sender has enough balance
      if (currentBalance < amountNum) {
        return res.status(400).json({ message: "Insufficient balance" });
      }

      // Update balances
      const newFromBalance = (currentBalance - amountNum).toFixed(2);
      const newToBalance = (parseFloat(toUser.balance) + amountNum).toFixed(2);

      await storage.updateUserBalance(fromUserId, newFromBalance);
      await storage.updateUserBalance(toUser.id, newToBalance);

      // Create transaction records
      await storage.createTransaction({
        fromUserId,
        toUserId: toUser.id,
        amount: amount,
        description: description || `Payment to ${toUser.firstName} ${toUser.lastName}`,
        type: "send",
      });

      await storage.createTransaction({
        fromUserId,
        toUserId: toUser.id,
        amount: amount,
        description: description || `Payment from ${fromUser.firstName} ${fromUser.lastName}`,
        type: "receive",
      });

      res.json({ message: "Money sent successfully" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Request money
  app.post("/api/transactions/request", requireAuth, async (req, res) => {
    try {
      const { toEmail, amount, description } = sendMoneySchema.parse(req.body);
      const fromUserId = req.session.user!.id;
      
      // Get requesting user
      const fromUser = await storage.getUser(fromUserId);
      if (!fromUser) {
        return res.status(404).json({ message: "User not found" });
      }

      // Get target user
      const toUser = await storage.getUserByEmail(toEmail);
      if (!toUser) {
        return res.status(404).json({ message: "Recipient not found" });
      }

      // For demo purposes, we'll just create a transaction record
      // In a real app, this would send a notification to the target user
      await storage.createTransaction({
        fromUserId,
        toUserId: toUser.id,
        amount: amount,
        description: description || `Money request from ${fromUser.firstName} ${fromUser.lastName}`,
        type: "request",
      });

      res.json({ message: "Money request sent successfully" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Withdraw money
  app.post("/api/withdrawals", requireAuth, async (req, res) => {
    try {
      const withdrawalData = insertWithdrawalSchema.parse({
        ...req.body,
        userId: req.session.user!.id,
      });
      
      const user = await storage.getUser(req.session.user!.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const amountNum = parseFloat(withdrawalData.amount);
      const currentBalance = parseFloat(user.balance);

      // Check if user has enough balance
      if (currentBalance < amountNum) {
        return res.status(400).json({ message: "Insufficient balance" });
      }

      // Update user balance
      const newBalance = (currentBalance - amountNum).toFixed(2);
      await storage.updateUserBalance(req.session.user!.id, newBalance);

      // Create withdrawal record
      const withdrawal = await storage.createWithdrawal(withdrawalData);

      // Create transaction record
      await storage.createTransaction({
        fromUserId: req.session.user!.id,
        toUserId: null,
        amount: withdrawalData.amount,
        description: `Withdrawal to ${withdrawalData.bankName}`,
        type: "withdraw",
      });

      res.json(withdrawal);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get user withdrawals
  app.get("/api/withdrawals", requireAuth, async (req, res) => {
    try {
      const withdrawals = await storage.getWithdrawalsByUserId(req.session.user!.id);
      res.json(withdrawals);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get user contacts
  app.get("/api/contacts", requireAuth, async (req, res) => {
    try {
      const contacts = await storage.getContactsByUserId(req.session.user!.id);
      res.json(contacts);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Verify email and get user info
  app.post("/api/users/verify-email", requireAuth, async (req, res) => {
    try {
      const { email } = req.body;
      
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Return basic user info for verification
      res.json({
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Add contact
  app.post("/api/contacts", requireAuth, async (req, res) => {
    try {
      const { email, nickname } = req.body;
      const userId = req.session.user!.id;
      
      const contactUser = await storage.getUserByEmail(email);
      if (!contactUser) {
        return res.status(404).json({ message: "User not found" });
      }

      const contact = await storage.createContact({
        userId,
        contactUserId: contactUser.id,
        nickname,
      });

      res.json(contact);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // PayPal routes
  app.get("/api/paypal/setup", async (req, res) => {
    await loadPaypalDefault(req, res);
  });

  app.post("/api/paypal/order", async (req, res) => {
    // Request body should contain: { intent, amount, currency }
    await createPaypalOrder(req, res);
  });

  app.post("/api/paypal/order/:orderID/capture", async (req, res) => {
    await capturePaypalOrder(req, res);
  });

  const httpServer = createServer(app);
  return httpServer;
}
