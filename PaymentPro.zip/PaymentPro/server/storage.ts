import { 
  users, 
  transactions, 
  contacts, 
  withdrawals,
  type User, 
  type InsertUser, 
  type Transaction, 
  type InsertTransaction,
  type Contact,
  type InsertContact,
  type Withdrawal,
  type InsertWithdrawal
} from "@shared/schema";
import { db } from "./db";
import { eq, or, desc } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserBalance(userId: number, newBalance: string): Promise<void>;

  // Transaction methods
  getTransactionsByUserId(userId: number): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  updateTransactionStatus(id: number, status: string, completedAt?: Date): Promise<void>;

  // Contact methods
  getContactsByUserId(userId: number): Promise<(Contact & { contactUser: User })[]>;
  createContact(contact: InsertContact): Promise<Contact>;

  // Withdrawal methods
  getWithdrawalsByUserId(userId: number): Promise<Withdrawal[]>;
  createWithdrawal(withdrawal: InsertWithdrawal): Promise<Withdrawal>;
  updateWithdrawalStatus(id: number, status: string, completedAt?: Date): Promise<void>;
  getPendingWithdrawals(): Promise<Withdrawal[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUserBalance(userId: number, newBalance: string): Promise<void> {
    await db
      .update(users)
      .set({ balance: newBalance })
      .where(eq(users.id, userId));
  }

  async getTransactionsByUserId(userId: number): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .where(or(eq(transactions.fromUserId, userId), eq(transactions.toUserId, userId)))
      .orderBy(desc(transactions.createdAt));
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const [transaction] = await db
      .insert(transactions)
      .values(insertTransaction)
      .returning();
    return transaction;
  }

  async updateTransactionStatus(id: number, status: string, completedAt?: Date): Promise<void> {
    await db
      .update(transactions)
      .set({ 
        status,
        completedAt: completedAt || null
      })
      .where(eq(transactions.id, id));
  }

  async getContactsByUserId(userId: number): Promise<(Contact & { contactUser: User })[]> {
    const contactsWithUsers = await db
      .select()
      .from(contacts)
      .leftJoin(users, eq(contacts.contactUserId, users.id))
      .where(eq(contacts.userId, userId));

    return contactsWithUsers.map(row => ({
      ...row.contacts,
      contactUser: row.users!
    }));
  }

  async createContact(insertContact: InsertContact): Promise<Contact> {
    const [contact] = await db
      .insert(contacts)
      .values(insertContact)
      .returning();
    return contact;
  }

  async getWithdrawalsByUserId(userId: number): Promise<Withdrawal[]> {
    return await db
      .select()
      .from(withdrawals)
      .where(eq(withdrawals.userId, userId))
      .orderBy(desc(withdrawals.createdAt));
  }

  async createWithdrawal(insertWithdrawal: InsertWithdrawal): Promise<Withdrawal> {
    const [withdrawal] = await db
      .insert(withdrawals)
      .values(insertWithdrawal)
      .returning();

    // Set 3-hour timer to complete withdrawal
    setTimeout(async () => {
      await this.updateWithdrawalStatus(withdrawal.id, "completed", new Date());
    }, 3 * 60 * 60 * 1000); // 3 hours

    return withdrawal;
  }

  async updateWithdrawalStatus(id: number, status: string, completedAt?: Date): Promise<void> {
    await db
      .update(withdrawals)
      .set({ 
        status,
        completedAt: completedAt || null
      })
      .where(eq(withdrawals.id, id));
  }

  async getPendingWithdrawals(): Promise<Withdrawal[]> {
    return await db
      .select()
      .from(withdrawals)
      .where(eq(withdrawals.status, "pending"));
  }
}

export const storage = new DatabaseStorage();
