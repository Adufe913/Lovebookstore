import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useUser } from "@/lib/auth";
import { formatCurrency } from "@/lib/format";
import { X, University, Info } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface WithdrawModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function WithdrawModal({ open, onOpenChange }: WithdrawModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: user } = useUser();
  const [formData, setFormData] = useState({
    amount: "",
    bankName: "Wells Fargo Bank",
    accountNumber: "****1234",
  });

  const withdrawMoney = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/withdrawals", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Withdrawal Initiated",
        description: "Your withdrawal is being processed. You'll receive an email confirmation when complete.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      queryClient.invalidateQueries({ queryKey: ["/api/withdrawals"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      onOpenChange(false);
      setFormData({ ...formData, amount: "" });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to process withdrawal",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.amount || parseFloat(formData.amount) <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid amount",
        variant: "destructive",
      });
      return;
    }

    if (user && parseFloat(formData.amount) > parseFloat(user.balance)) {
      toast({
        title: "Insufficient Funds",
        description: "You don't have enough balance for this withdrawal",
        variant: "destructive",
      });
      return;
    }

    withdrawMoney.mutate(formData);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-xl font-semibold text-gray-900">Withdraw to Bank</DialogTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onOpenChange(false)}
              className="text-gray-400 hover:text-gray-600"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
        </DialogHeader>
        
        <div className="w-full h-32 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg mb-4 bg-cover bg-center"
             style={{
               backgroundImage: "url('https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200')"
             }}>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="amount" className="block text-sm font-medium text-gray-700 mb-2">
              Amount to withdraw
            </Label>
            <div className="relative">
              <span className="absolute left-3 top-3 text-gray-500 text-lg">$</span>
              <Input
                id="amount"
                type="number"
                step="0.01"
                min="0"
                placeholder="0.00"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                className="w-full pl-8 text-lg"
                required
              />
            </div>
            {user && (
              <p className="text-sm text-gray-500 mt-1">
                Available balance: {formatCurrency(user.balance)}
              </p>
            )}
          </div>
          
          <div>
            <Label className="block text-sm font-medium text-gray-700 mb-2">
              Withdraw to
            </Label>
            <div className="border border-gray-300 rounded-lg p-4 bg-gray-50">
              <div className="flex items-center space-x-3">
                <University className="text-pal-blue h-5 w-5" />
                <div>
                  <p className="font-medium text-gray-900">{formData.bankName}</p>
                  <p className="text-sm text-gray-500">{formData.accountNumber}</p>
                </div>
              </div>
            </div>
          </div>
          
          <Alert className="bg-yellow-50 border-yellow-200">
            <Info className="h-4 w-4 text-yellow-600" />
            <AlertDescription className="text-yellow-800">
              <p className="font-medium">Processing Time</p>
              <p className="text-sm">Withdrawals are processed within 3 hours. You'll receive an email confirmation when complete.</p>
            </AlertDescription>
          </Alert>
          
          <Button
            type="submit"
            className="w-full bg-pal-blue text-white hover:bg-pal-dark-blue"
            disabled={withdrawMoney.isPending}
          >
            {withdrawMoney.isPending ? "Processing..." : "Withdraw Money"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
