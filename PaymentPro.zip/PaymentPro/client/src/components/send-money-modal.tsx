import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { sendMoneySchema, type SendMoneyData } from "@shared/schema";
import { X, Check, AlertTriangle } from "lucide-react";
import PayPalButton from "./PayPalButton";

interface SendMoneyModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  prefilledEmail?: string;
}

export function SendMoneyModal({ open, onOpenChange, prefilledEmail }: SendMoneyModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    toEmail: prefilledEmail || "",
    amount: "",
    description: "",
  });
  const [verifiedUser, setVerifiedUser] = useState<{firstName: string, lastName: string, email: string} | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const [showPayPal, setShowPayPal] = useState(false);

  const verifyEmail = useMutation({
    mutationFn: async (email: string) => {
      const response = await apiRequest("POST", "/api/users/verify-email", { email });
      return response.json();
    },
    onSuccess: (data) => {
      setVerifiedUser(data);
      setIsVerifying(false);
      toast({
        title: "Email Verified",
        description: `Ready to send money to ${data.firstName} ${data.lastName}`,
      });
    },
    onError: (error: any) => {
      setVerifiedUser(null);
      setIsVerifying(false);
      toast({
        title: "User Not Found",
        description: "This email is not registered in our system",
        variant: "destructive",
      });
    },
  });

  const sendMoney = useMutation({
    mutationFn: async (data: SendMoneyData) => {
      const response = await apiRequest("POST", "/api/transactions/send", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Money sent successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      onOpenChange(false);
      setFormData({ toEmail: "", amount: "", description: "" });
      setVerifiedUser(null);
      setShowPayPal(false);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to send money",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const validatedData = sendMoneySchema.parse(formData);
      sendMoney.mutate(validatedData);
    } catch (error: any) {
      toast({
        title: "Validation Error",
        description: error.errors?.[0]?.message || "Please check your input",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-xl font-semibold text-gray-900">Send Money</DialogTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onOpenChange(false)}
              className="text-gray-400 hover:text-gray-600"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="toEmail" className="block text-sm font-medium text-gray-700 mb-2">
              Send to
            </Label>
            <Input
              id="toEmail"
              type="email"
              placeholder="Email address or phone number"
              value={formData.toEmail}
              onChange={(e) => setFormData({ ...formData, toEmail: e.target.value })}
              className="w-full"
              required
            />
          </div>
          
          <div>
            <Label htmlFor="amount" className="block text-sm font-medium text-gray-700 mb-2">
              Amount
            </Label>
            <div className="relative">
              <span className="absolute left-3 top-3 text-gray-500 text-lg">$</span>
              <Input
                id="amount"
                type="number"
                step="0.01"
                min="0"
                placeholder="0.00"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                className="w-full pl-8 text-lg"
                required
              />
            </div>
          </div>
          
          <div>
            <Label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-2">
              What's this for? (Optional)
            </Label>
            <Input
              id="description"
              placeholder="Add a note"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full"
            />
          </div>
          
          <div className="pt-4">
            <Button
              type="submit"
              className="w-full bg-pal-blue text-white hover:bg-pal-dark-blue"
              disabled={sendMoney.isPending}
            >
              {sendMoney.isPending ? "Sending..." : "Send Money"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
