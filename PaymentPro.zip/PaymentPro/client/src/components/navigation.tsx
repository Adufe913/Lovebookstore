import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Bell, ChevronDown, Home, Send, Scan, List, MoreHorizontal, User } from "lucide-react";
import { useUser, useLogout } from "@/lib/auth";
import { getInitials } from "@/lib/format";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function Navigation() {
  const { data: user } = useUser();
  const logout = useLogout();
  const [location] = useLocation();

  if (!user) return null;

  const handleLogout = () => {
    logout.mutate();
  };

  return (
    <>
      {/* Desktop Navigation */}
      <nav className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Link href="/dashboard">
                  <h1 className="text-2xl font-bold text-pal-blue cursor-pointer">PalMoney</h1>
                </Link>
              </div>
              <div className="hidden md:block ml-10">
                <div className="flex items-baseline space-x-4">
                  <Link href="/dashboard" className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    location === "/dashboard" ? "text-gray-900" : "text-gray-600 hover:text-gray-900"
                  } hover:bg-gray-100`}>
                    Dashboard
                  </Link>
                  <Link href="/send" className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    location === "/send" ? "text-gray-900" : "text-gray-600 hover:text-gray-900"
                  } hover:bg-gray-100`}>
                    Send
                  </Link>
                  <Link href="/request" className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    location === "/request" ? "text-gray-900" : "text-gray-600 hover:text-gray-900"
                  } hover:bg-gray-100`}>
                    Request
                  </Link>
                  <Link href="/activity" className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    location === "/activity" ? "text-gray-900" : "text-gray-600 hover:text-gray-900"
                  } hover:bg-gray-100`}>
                    Activity
                  </Link>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" className="text-gray-600 hover:text-gray-900">
                <Bell className="h-5 w-5" />
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center space-x-2 text-gray-700 hover:text-gray-900">
                    <div className="w-8 h-8 bg-pal-blue rounded-full flex items-center justify-center">
                      <span className="text-white font-medium text-sm">
                        {getInitials(user.firstName, user.lastName)}
                      </span>
                    </div>
                    <span className="hidden md:block text-sm font-medium">
                      {user.firstName} {user.lastName}
                    </span>
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem>
                    <User className="mr-2 h-4 w-4" />
                    Profile
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleLogout}>
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 md:hidden z-40">
        <div className="grid grid-cols-5 py-2">
          <Link href="/dashboard" className={`flex flex-col items-center py-2 px-1 ${
            location === "/dashboard" ? "text-pal-blue" : "text-gray-600"
          }`}>
            <Home className="h-5 w-5 mb-1" />
            <span className="text-xs font-medium">Home</span>
          </Link>
          <Link href="/send" className={`flex flex-col items-center py-2 px-1 ${
            location === "/send" ? "text-pal-blue" : "text-gray-600"
          }`}>
            <Send className="h-5 w-5 mb-1" />
            <span className="text-xs font-medium">Send</span>
          </Link>
          <Link href="/scan" className={`flex flex-col items-center py-2 px-1 ${
            location === "/scan" ? "text-pal-blue" : "text-gray-600"
          }`}>
            <Scan className="h-5 w-5 mb-1" />
            <span className="text-xs font-medium">Scan</span>
          </Link>
          <Link href="/activity" className={`flex flex-col items-center py-2 px-1 ${
            location === "/activity" ? "text-pal-blue" : "text-gray-600"
          }`}>
            <List className="h-5 w-5 mb-1" />
            <span className="text-xs font-medium">Activity</span>
          </Link>
          <Link href="/more" className={`flex flex-col items-center py-2 px-1 ${
            location === "/more" ? "text-pal-blue" : "text-gray-600"
          }`}>
            <MoreHorizontal className="h-5 w-5 mb-1" />
            <span className="text-xs font-medium">More</span>
          </Link>
        </div>
      </nav>
    </>
  );
}
