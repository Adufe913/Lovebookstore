import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useUser } from "@/lib/auth";
import { formatCurrency, formatDate, getInitials } from "@/lib/format";
import { SendMoneyModal } from "@/components/send-money-modal";
import { RequestMoneyModal } from "@/components/request-money-modal";
import { WithdrawModal } from "@/components/withdraw-modal";
import { 
  Wallet, 
  Send, 
  DollarSign, 
  University, 
  Plus, 
  FileText, 
  CreditCard,
  ArrowDown,
  ArrowUp,
  Clock,
  CheckCircle,
  Shield,
  MessageCircle,
  Mail
} from "lucide-react";
import type { Transaction, Contact, User } from "@shared/schema";

export default function Dashboard() {
  const { data: user } = useUser();
  const [sendModalOpen, setSendModalOpen] = useState(false);
  const [requestModalOpen, setRequestModalOpen] = useState(false);
  const [withdrawModalOpen, setWithdrawModalOpen] = useState(false);
  const [prefilledEmail, setPrefilledEmail] = useState("");

  const { data: transactions = [] } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
    enabled: !!user,
  });

  const { data: contacts = [] } = useQuery<(Contact & { contactUser: User })[]>({
    queryKey: ["/api/contacts"],
    enabled: !!user,
  });

  const { data: withdrawals = [] } = useQuery({
    queryKey: ["/api/withdrawals"],
    enabled: !!user,
  });

  if (!user) return null;

  const pendingWithdrawalsAmount = withdrawals
    .filter((w: any) => w.status === "pending")
    .reduce((sum: number, w: any) => sum + parseFloat(w.amount), 0);

  const monthlyActivity = transactions
    .filter(t => {
      const transactionDate = new Date(t.createdAt);
      const now = new Date();
      return transactionDate.getMonth() === now.getMonth() && 
             transactionDate.getFullYear() === now.getFullYear();
    })
    .reduce((sum, t) => sum + parseFloat(t.amount), 0);

  const handleQuickPay = (email: string) => {
    setPrefilledEmail(email);
    setSendModalOpen(true);
  };

  const getTransactionIcon = (transaction: Transaction) => {
    if (transaction.type === "receive" || (transaction.type === "send" && transaction.toUserId === user.id)) {
      return <ArrowDown className="text-green-600 h-5 w-5" />;
    } else if (transaction.type === "withdraw") {
      return <Clock className="text-yellow-600 h-5 w-5" />;
    } else {
      return <ArrowUp className="text-red-600 h-5 w-5" />;
    }
  };

  const getTransactionAmount = (transaction: Transaction) => {
    const isReceiving = transaction.type === "receive" || 
                       (transaction.type === "send" && transaction.toUserId === user.id);
    const amount = parseFloat(transaction.amount);
    return isReceiving ? `+${formatCurrency(amount)}` : `-${formatCurrency(amount)}`;
  };

  const getTransactionAmountColor = (transaction: Transaction) => {
    const isReceiving = transaction.type === "receive" || 
                       (transaction.type === "send" && transaction.toUserId === user.id);
    return isReceiving ? "text-green-600" : "text-red-600";
  };

  return (
    <div className="pb-mobile-nav">
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <Card className="border-none shadow-sm">
            <CardContent className="p-6 md:p-8">
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between">
                <div className="mb-6 md:mb-0">
                  <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">
                    Welcome back, {user.firstName}!
                  </h2>
                  <p className="text-gray-600">Manage your payments and view your financial activity</p>
                </div>
                <div className="w-full md:w-80 h-48 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg bg-cover bg-center"
                     style={{
                       backgroundImage: "url('https://images.unsplash.com/photo-1563986768609-322da13575f3?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250')"
                     }}>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Balance Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="md:col-span-2">
            <Card className="bg-gradient-pal border-none shadow-lg text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">Available Balance</h3>
                  <Wallet className="h-6 w-6 opacity-80" />
                </div>
                <div className="mb-6">
                  <span className="text-4xl font-bold">{formatCurrency(user.balance)}</span>
                  <p className="text-blue-100 mt-1">USD</p>
                </div>
                <div className="flex flex-col sm:flex-row gap-3">
                  <Button 
                    onClick={() => setSendModalOpen(true)}
                    className="bg-white text-pal-blue hover:bg-gray-50 flex items-center justify-center"
                  >
                    <Send className="mr-2 h-4 w-4" />
                    Send Money
                  </Button>
                  <Button 
                    onClick={() => setRequestModalOpen(true)}
                    className="bg-pal-dark-blue text-white hover:bg-blue-900 flex items-center justify-center"
                  >
                    <DollarSign className="mr-2 h-4 w-4" />
                    Request Money
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
          <div className="space-y-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-gray-600 text-sm">Pending Withdrawals</span>
                  <Clock className="h-4 w-4 text-yellow-500" />
                </div>
                <span className="text-2xl font-bold text-gray-900">
                  {formatCurrency(pendingWithdrawalsAmount)}
                </span>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-gray-600 text-sm">This Month</span>
                  <CheckCircle className="h-4 w-4 text-green-500" />
                </div>
                <span className="text-2xl font-bold text-gray-900">
                  {formatCurrency(monthlyActivity)}
                </span>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Quick Actions */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-6">Quick Actions</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Button
                variant="outline"
                onClick={() => setWithdrawModalOpen(true)}
                className="flex flex-col items-center p-4 h-auto border-2 hover:border-pal-blue hover:bg-pal-light-blue"
              >
                <University className="h-6 w-6 text-pal-blue mb-2" />
                <span className="text-sm font-medium">Withdraw</span>
              </Button>
              <Button
                variant="outline"
                className="flex flex-col items-center p-4 h-auto border-2 hover:border-pal-blue hover:bg-pal-light-blue"
              >
                <Plus className="h-6 w-6 text-pal-blue mb-2" />
                <span className="text-sm font-medium">Add Money</span>
              </Button>
              <Button
                variant="outline"
                className="flex flex-col items-center p-4 h-auto border-2 hover:border-pal-blue hover:bg-pal-light-blue"
              >
                <FileText className="h-6 w-6 text-pal-blue mb-2" />
                <span className="text-sm font-medium">Pay Bills</span>
              </Button>
              <Button
                variant="outline"
                className="flex flex-col items-center p-4 h-auto border-2 hover:border-pal-blue hover:bg-pal-light-blue"
              >
                <CreditCard className="h-6 w-6 text-pal-blue mb-2" />
                <span className="text-sm font-medium">Cards</span>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity and Contacts */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-semibold text-gray-900">Recent Activity</h3>
                  <Button variant="link" className="text-pal-blue hover:text-pal-dark-blue">
                    View All
                  </Button>
                </div>
                <div className="space-y-4">
                  {transactions.slice(0, 4).map((transaction) => (
                    <div
                      key={transaction.id}
                      className="flex items-center justify-between p-4 border border-gray-100 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                          {getTransactionIcon(transaction)}
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">{transaction.description}</p>
                          <p className="text-sm text-gray-500">{formatDate(transaction.createdAt)}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className={`font-semibold ${getTransactionAmountColor(transaction)}`}>
                          {getTransactionAmount(transaction)}
                        </p>
                        <Badge variant={transaction.status === "completed" ? "default" : "secondary"}>
                          {transaction.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                  {transactions.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      <p>No transactions yet</p>
                      <p className="text-sm">Start by sending or receiving money</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Contacts and Support */}
          <div className="space-y-6">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Pay Contacts</h3>
                <div className="space-y-3">
                  {contacts.slice(0, 3).map((contact) => (
                    <div key={contact.id} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                          <span className="text-sm font-medium text-gray-600">
                            {getInitials(contact.contactUser.firstName, contact.contactUser.lastName)}
                          </span>
                        </div>
                        <span className="text-sm font-medium text-gray-900">
                          {contact.contactUser.firstName} {contact.contactUser.lastName}
                        </span>
                      </div>
                      <Button
                        variant="link"
                        onClick={() => handleQuickPay(contact.contactUser.email)}
                        className="text-pal-blue hover:text-pal-dark-blue text-sm"
                      >
                        Pay
                      </Button>
                    </div>
                  ))}
                </div>
                <Button 
                  variant="outline" 
                  className="w-full mt-4 border-pal-blue text-pal-blue hover:bg-pal-light-blue"
                >
                  Manage Contacts
                </Button>
              </CardContent>
            </Card>

            {/* Customer Support */}
            <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
              <CardContent className="p-6">
                <div className="w-full h-32 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg mb-4 bg-cover bg-center"
                     style={{
                       backgroundImage: "url('https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200')"
                     }}>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Need Help?</h3>
                <p className="text-gray-600 text-sm mb-4">Our customer service team is here to assist you 24/7</p>
                <div className="space-y-2">
                  <a 
                    href="mailto:24hrsreplypal@gmail.com" 
                    className="flex items-center text-pal-blue hover:text-pal-dark-blue text-sm font-medium"
                  >
                    <Mail className="mr-2 h-4 w-4" />
                    24hrsreplypal@gmail.com
                  </a>
                  <Button className="w-full bg-pal-blue text-white hover:bg-pal-dark-blue">
                    <MessageCircle className="mr-2 h-4 w-4" />
                    Start Live Chat
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Security Notice */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-start space-x-3">
                  <Shield className="text-pal-blue h-5 w-5 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900 text-sm mb-1">Your Security Matters</h4>
                    <p className="text-gray-600 text-xs mb-2">
                      Your account is protected with bank-level security. Enable 2FA for extra protection.
                    </p>
                    <Button variant="link" className="text-pal-blue hover:text-pal-dark-blue text-xs p-0">
                      Enable 2FA →
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Modals */}
      <SendMoneyModal 
        open={sendModalOpen} 
        onOpenChange={setSendModalOpen}
        prefilledEmail={prefilledEmail}
      />
      <RequestMoneyModal 
        open={requestModalOpen} 
        onOpenChange={setRequestModalOpen}
      />
      <WithdrawModal 
        open={withdrawModalOpen} 
        onOpenChange={setWithdrawModalOpen}
      />
    </div>
  );
}
